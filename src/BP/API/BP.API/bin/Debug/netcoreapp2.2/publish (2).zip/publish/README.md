# Introduction
Bem-vindo a API do desafio da Braspag. Esta documenta&ccedil;&atilde;o exp&otilde;e os endpoints de MDR e Transaction sem a utiliza&ccedil;&atilde;o de banco de dados.
